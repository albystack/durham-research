# Strict-annealed Julia results

## Sampling design

- 379,000 loop-erased random walks in 379,000 independently seeded site environments.
- Exactly one walk per environment; no random background is reused.
- 3,790 atomic tasks, all complete, with zero failed observations.
- 15 weight specifications from `L=16` through `L=4096`.
- Baseline and Gamma(shape=1) additionally include `L=8192`.
- Source fingerprint: `2f619b8+source.020484b0bc41`; Julia 1.12.6.

Each site environment is generated lazily but deterministically from its unique
environment seed and lattice coordinate. Cache eviction therefore regenerates
the same weights and does not alter the background.

## Main result

Fitting

```text
Var(W_L) = C (log L)^p
```

over all simulated sizes gives `p` between 1.011 and 1.160 across the 15
specifications. The 95% environment-bootstrap intervals have upper bounds
between 1.093 and 1.236, all far below 2.

The additive model comparison fits `a + b log L` and `a + b (log L)^2`.
Ordinary logarithmic growth has lower BIC in 14 of 15 cases. Pareto(alpha=2)
has `BIC(log^2) - BIC(log) = -0.24`, which is an effective tie and not robust
evidence for squared-log growth. Baseline and Gamma(shape=1), the two cases
extended to `L=8192`, also remain close to the ordinary-log trend.

The defensible conclusion is therefore:

> The strict-annealed data show no robust `(log L)^2` regime over the simulated
> sizes. Effective exponents remain close to 1, and model comparison is broadly
> consistent with ordinary logarithmic winding-variance growth.

Some bootstrap intervals exclude `p=1` slightly on the high side. These should
be described as finite-size effective exponents, not as evidence for `p=2`.
The Pareto(alpha=2) BIC near-tie should also be reported rather than hidden.

## Key fitted values

| Case | p | 95% bootstrap interval | BIC(log^2) - BIC(log) |
|---|---:|---:|---:|
| Baseline | 1.144 | [1.070, 1.213] | 1.51 |
| Gamma(shape=1) | 1.146 | [1.067, 1.216] | 0.74 |
| Minimum across cases | 1.011 | [0.927, 1.093] | 14.63 |
| Maximum across cases | 1.160 | [1.078, 1.236] | 5.50 |
| Pareto(alpha=2) | 1.095 | [1.020, 1.164] | -0.24 |

The minimum row is Pareto(alpha=3); the maximum row is Gamma(shape=2).

## Files for review

- `strict_annealed_results_for_chhita.pdf`: short five-page summary prepared for
  email, covering validation, the main plots, model comparison, and the two
  `L=8192` checks.
- `professor_chhita_handoff.zip`: compact attachment containing this handoff,
  the email draft, frozen configuration, validation table, analysis tables, and
  all PDF figures (the 94 MB raw CSV remains separate).
- `figures/annealed_scaling_all_distributions.pdf`: all variance curves and both additive fits.
- `figures/scaling_exponent_forest.pdf`: exponent estimates and bootstrap intervals.
- `figures/bic_model_comparison.pdf`: BIC difference for every specification.
- `figures/by_distribution/`: individual PNG and PDF panels.
- `summary.csv`: cell-level estimates and standard errors.
- `loglog_fits.csv`: exponent fits and bootstrap intervals.
- `scaling_model_comparison.csv`: additive log versus squared-log fits.
- `local_effective_exponents.csv`: adjacent-size effective exponents.
- `pointwise_ratios.csv`: pointwise transformed values.
- `../research-julia/analysis_strict_annealed/validation.csv`: task-level completeness audit.
- `../research-julia/analysis_strict_annealed/combined_raw.csv`: validated combined raw data.

## Reproduction

Commands and the frozen production design are documented in
`../research-julia/README.md`. The Julia test suite passes all 63 assertions.
