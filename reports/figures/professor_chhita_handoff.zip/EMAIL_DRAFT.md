Dear Professor Chhita,

Many thanks. I have now completed the rerun you suggested, using exactly one
loop-erased random walk per independently seeded environment. Thus no random
background is reused between walks, and the annealed interpretation is exact
in the sense we discussed.

The final strict-annealed dataset contains 379,000 walks from 379,000
environments across 15 weight distributions. All cases were run from L = 16
to L = 4096, with the baseline and Gamma(shape = 1) cases also extended to
L = 8192. The validation found no missing or failed runs.

The results are very similar to the previous ones. The fitted effective
exponent in

Var(W_L) = C (log L)^p

ranges from about 1.01 to 1.16 across the distributions, and all 95% bootstrap
intervals remain far below p = 2. The additive log L model is preferred by BIC
in 14 of 15 cases. The remaining Pareto(alpha = 2) case is essentially tied
between the two models, rather than providing clear evidence for (log L)^2
growth. The L = 8192 baseline and Gamma(shape = 1) points also remain
consistent with the ordinary-log trend.

I have attached a short PDF summarising the sampling design, validation, main
plots and fitted results. My reading is that using a completely fresh
environment for every walk does not reveal a robust super-rough regime over
the simulated sizes.

Please let me know if you would also like the full data or any further
diagnostics.

Best wishes,
Alberto
