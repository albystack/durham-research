# Source modules

The active package is intentionally split by mathematical construction.

- [`AztecDiamond.jl`](AztecDiamond.jl) is the package entry point and contains
  weighted domino shuffling, height observables, validation, and rendering.
- [`GlauberSquareGrid.jl`](GlauberSquareGrid.jl) contains direct square-grid
  dimer heat-bath dynamics, exact enumeration, event-driven acceleration,
  replica exchange, and dense finite-volume Kasteleyn moments. The Kasteleyn
  path solves only the inverse columns needed by a height path and supports a
  high-precision fallback for poorly conditioned environments.

Public functions use explicit random-number generators. Reference and
optimized paths are kept separate wherever exact comparison is possible.
Command-line parsing, files, and scheduler concerns belong in `../scripts/`,
not in these modules.

The former spanning-tree / Temperley module is preserved in
[`archive/experiments/square_grid/`](../../archive/experiments/square_grid/)
and is not imported by this package.
